async function fetchRover() {
  try {
    //Petición a la API de la nasa para conocer los datos del rover Curiosity
    const response = await axios.get('https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity?api_key=zA6lqZWflc9FE2YwBrE0AxaMaRu7OFzzhlktodkg');
    //console.log(`GET: Datos del rover`, response.data);
    //Hacer que la función regrese los datos del rover obtenidos de la petición a la API para poderlos utilizar
    return response.data.rover;
  } catch (errors) {
    console.error(errors);
  }
};

async function fetchNasa(maxSol) {
  try {
    //const response = await axios.get(`https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?sol=${atributo}&api_key=zA6lqZWflc9FE2YwBrE0AxaMaRu7OFzzhlktodkg&page=1`);
    const response = await axios.get(`https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?sol=${maxSol}&api_key=zA6lqZWflc9FE2YwBrE0AxaMaRu7OFzzhlktodkg&page=1`);
    //console.log(`GET: Here's the list of todos`, response.data);
    return response.data.photos;
  } catch (errors) {
    console.error(errors);
  }
};

var row = document.querySelector('.row');

async function mostrarFoto() {
  const datosRover = await fetchRover();
  console.log(datosRover.name);
  console.log(datosRover.max_sol.toString());
  const maxSol = datosRover.max_sol;
  var solesRover = document.getElementById('datos-rover');
  solesRover.setAttribute('class', 'datos-rover')
  solesRover.innerHTML = `El rover ${datosRover.name} lleva ${datosRover.max_sol.toString()} en Marte <br><br> 
                          En seguida se muestran algunas imágenes tomadas durante el último sol`
  const arregloFotos = await fetchNasa(maxSol);
  console.log(arregloFotos);
  for (var i = 0; i < arregloFotos.length; i++) {
    ////////////////////////////////////////////////////////////
    var col = document.createElement('div');
    col.setAttribute('class', "col-md-4 mt-5");
    row.appendChild(col);
    ////////////////////////////////////////////////////////////
    var card = document.createElement('div');
    card.setAttribute('class', "card");
    col.appendChild(card);
    ////////////////////////////////////////////////////////////
    var img = document.createElement('img');
    img.setAttribute("class", "card-img-top")
    img.setAttribute("src", arregloFotos[i].img_src);
    card.appendChild(img);
    ////////////////////////////////////////////////////////////
    var cuerpo = document.createElement('div');
    cuerpo.setAttribute('class', "card-body");
    card.appendChild(cuerpo);
    ////////////////////////////////////////////////////////////
    var numero = document.createElement('p');
    numero.setAttribute('class', "card-text");
    numero.innerHTML = 'Fotografía: ' + arregloFotos[i].id;
    cuerpo.appendChild(numero);
    ////////////////////////////////////////////////////////////
    var rov = document.createElement('p');
    rov.setAttribute('class', "card-text");
    rov.innerHTML = 'ROVER: ' + arregloFotos[i].rover.name;
    cuerpo.appendChild(rov);
    ////////////////////////////////////////////////////////////
    var camra = document.createElement('p');
    camra.setAttribute('class', "card-text");
    camra.innerHTML = 'Camara: ' + arregloFotos[i].camera.name;
    cuerpo.appendChild(camra);
    ////////////////////////////////////////////////////////////

  }
}

mostrarFoto();


